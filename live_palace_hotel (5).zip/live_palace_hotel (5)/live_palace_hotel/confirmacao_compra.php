<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    // Configurações do servidor
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'your-email@gmail.com'; // Seu endereço de e-mail Gmail
    $mail->Password   = 'your-email-password'; // Sua senha do Gmail
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Opções para desabilitar a verificação do certificado SSL (temporário)
    $mail->SMTPOptions = array(
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        )
    );

    // Destinatários
    $mail->setFrom('your-email@gmail.com', 'Live Palace Hotel');
    $mail->addAddress('destinatario@example.com'); // Adicione o destinatário

    // Conteúdo do e-mail
    $mail->isHTML(true);
    $mail->Subject = 'Confirmação de Compra - Live Palace Hotel';
    $mail->Body    = 'Seu conteúdo HTML aqui...';

    // Enviar o e-mail
    $mail->send();
    echo 'E-mail enviado com sucesso!';
} catch (Exception $e) {
    echo "Falha ao enviar e-mail. Erro de Mailer: {$mail->ErrorInfo}";
}
?>
