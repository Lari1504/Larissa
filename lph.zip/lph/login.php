<?php include_once("funcoes.php"); ?>
<?php include_once("header.php"); ?>
<br><br><br><br>
<main>
    <section>
        <h2>Login</h2>
        <form action="loginTeste.php" method="post">
            <label for="username">Usuário:</label><br>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Senha:</label><br>
            <input type="password" id="password" name="password" required><br><br>
            <button type="submit" name="login">Login</button>
        </form>
    </section>
</main>
<p class="link">
    Não tem conta?
    <a href="registro.php">Faça o seu cadastro</a>
</p>
<?php include_once("footer.php"); ?>
