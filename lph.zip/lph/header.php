<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Palace Hotel</title>
    <link rel="stylesheet" href="css/header_login.css">
</head>
<body>
    <header>
        <h1>Live Palace Hotel</h1>
        <?php if(isset($_SESSION['nome'])): ?>
            <p>Bem-vindo!</p>
        <?php endif; ?>
        <nav>
            <ul>
                <?php if(isset($_SESSION['nome'])): ?>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="logout.php">Sair</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="registro.php">Cadastro</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
