<?php
include_once("conecao.php");
session_start();

function registrarUsuario($conn, $username, $password) {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (email, password) VALUES ('$email', '$senha')";
    
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}

function realizarLogin($conn, $usuario, $senha) {
    $sql = "SELECT * FROM users WHERE email='$usuario'";
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if(password_verify($password, $row['senha'])) {
            $_SESSION['email'] = $usuario;
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

if(isset($_POST['register'])) {
    $username = $_POST['usuario'];
    $password = $_POST['senha'];
    
    if(registrarUsuario($conn, $usuario, $senha)) {
        header("Location: login.php");
        exit();
    } else {
        echo "Erro ao registrar usuário.";
    }
}

if(isset($_POST['login'])) {
    $username = $_POST['email'];
    $password = $_POST['senha'];
    
    if(realizarLogin($conn, $usuario, $senha)) {
        header("Location: painel.php");
        exit();
    } else {
        echo "Usuário ou senha inválidos.";
    }
}
?>
