DROP DATABASE IF EXISTS hotel;
CREATE DATABASE hotel;
USE hotel;

CREATE TABLE login (
  usuario_id INT NOT NULL AUTO_INCREMENT,
  email VARCHAR(50) NOT NULL,
  nome VARCHAR(45) NOT NULL,
  senha VARCHAR(45) NOT NULL,
  data_cadastro DATETIME NOT NULL,
  PRIMARY KEY (usuario_id)
);

CREATE TABLE reservar(
  id INT NOT NULL AUTO_INCREMENT,
  v_entrada DATE NOT NULL,
  v_saida DATE NOT NULL,
  quartos INT NOT NULL,
  PRIMARY KEY (id)
);

INSERT INTO login (email, nome, senha, data_cadastro) VALUES ("jp@gmail.com", "joao", "1234", NOW());
INSERT INTO login (email, nome, senha, data_cadastro) VALUES ("lari@gmail.com", "lari", "4567", NOW());

SELECT * FROM login;

INSERT INTO reservar (v_entrada, v_saida, quartos) VALUES ("2024-04-04", "2024-06-15", 1);
INSERT INTO reservar (v_entrada, v_saida, quartos) VALUES ("2024-04-06", "2024-06-12", 2);

SELECT * FROM reservar;