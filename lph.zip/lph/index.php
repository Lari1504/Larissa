<?php
session_start(); // Inicia a sessão

// Verifica se o usuário está logado
if(!isset($_SESSION['nome'])) {
    // Se não estiver logado, redireciona para a página de login
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Palace Hotel</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
<header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="quartos.php">Quartos</a></li>
            <li><a href="consumo.php">Consumo</a></li>
            <li><a href="galeria.php">Galeria</a></li>
            <li><a href="carrinho.php">Carrinho</a></li>
            <li><a href="contato.php">Contato</a></li>
            <li><a href="logout.php">Sair</a></li>
        </ul>
    </nav>
</header>

<div class="banner">
    <img src="img/banner.png" alt="Banner do Live Palace Hotel">
</div>

<main>
    <?php if(isset($_SESSION['nome'])): ?>
        <h2>Bem-vindo a tela de check-in! 
        <h3>Reserva</h3>
        <p>Faça sua reserva agora!</p>
        <form action="index.php" method="post">
            <label for="checkin">Check-in:</label>
            <input type="date" id="checkin" name="checkin" required><br>
            <label for="checkout">Check-out:</label>
            <input type="date" id="checkout" name="checkout" required><br>
            <input type="submit" value="Reservar">
        </form>
    <?php endif; ?>
</main>

<!-- TITULO CENTRALIZADO FAÇA SUA RESERVA -->

<!-- QUARTO E SUÍTES, COM FOTO, DESCRIÇÃO DO QUARTO, VALOR BUTÃO RESERVAR -->


<!-- CARROSSEL COM AS FOTOS -->



<footer>
    <p>&copy; <?php echo date("Y"); ?> Live Palace Hotel. Todos os direitos reservados a Larissa Tauanny.</p>
</footer>
</body>
</html>