<?php
session_start();
if (!isset($_SESSION['nome'])) {
    header("Location: login.php");
    exit();
}

include_once("conexao.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['checkin']) && isset($_POST['checkout']) && !empty($_POST['checkin']) && !empty($_POST['checkout'])) {
        $checkin = $_POST['checkin'];
        $checkout = $_POST['checkout'];
        
        // Inserindo os dados da reserva no banco de dados
        $sql = "INSERT INTO reservar (v_entrada, v_saida, quartos) VALUES ('$checkin', '$checkout', 1)";
        
        if (mysqli_query($conexao, $sql)) {
            echo "Sua reserva foi feita com sucesso para o período de $checkin a $checkout!";
        } else {
            echo "Erro ao fazer a reserva. Por favor, tente novamente.";
        }

        mysqli_close($conexao);
    } else {
        echo "Por favor, preencha todos os campos do formulário.";
    }
} else {
    header("Location: index.php");
    exit();
}
?>
