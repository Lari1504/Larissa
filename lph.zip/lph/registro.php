<?php include_once("funcoes.php"); ?>
<?php include_once("header.php"); ?>
<br><br><br><br>
<main>
    <section>
        <h2>Cadastro</h2>
        <form action="register.php" method="post">
            <label for="username">Usuário:</label><br>
            <input type="text" id="username" name="username" required><br>
            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br>
            <label for="password">Senha:</label><br>
            <input type="password" id="password" name="password" required><br><br>
            <button type="submit" name="register">Cadastrar</button>
        </form>
    </section>
</main>
<p class="link">
           Já tem conta?
            <a href="login.php">Faça o seu login</a>
     </p>
<?php include_once("footer.php"); ?>
