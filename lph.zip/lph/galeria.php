<?php include_once("header.php"); ?>
<div class="container">

       <h1 class="title">Galeria</h1>
       <div class="row gallery">
              <div class="col-sm-4 wowload fadeInUp"><a href="img/comida1.jpg" title="Foods" class="gallery-image" data-gallery><img src="img/comida1.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/comida2.jpg" title="Coffee" class="gallery-image" data-gallery><img src="img/comida2.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/comida3.jpg" title="Travel" class="gallery-image" data-gallery><img src="img/comida3.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/agua.jpg" title="Adventure" class="gallery-image" data-gallery><img src="img/agua.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/bolinho.jpg" title="Fruits" class="gallery-image" data-gallery><img src="img/bolinho.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/cafe_com_leite.jpg" title="Summer" class="gallery-image" data-gallery><img src="img/cafe_com_leite.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/cafe.jpg" title="Bathroom" class="gallery-image" data-gallery><img src="img/cafe.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/whisky.jpg" title="Rooms" class="gallery-image" data-gallery><img src="img/whisky.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/lazer1.jpg" title="Big Room" class="gallery-image" data-gallery><img src="img/lazer1.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/lazer2.jpg" title="Living Room" class="gallery-image" data-gallery><img src="img/lazer2.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/lazer3.jpg" title="Fruits" class="gallery-image" data-gallery><img src="img/lazer3.jpg" class="img-responsive"></a></div><br>
              <div class="col-sm-4 wowload fadeInUp"><a href="img/lazer4.jpg" title="Travel" class="gallery-image" data-gallery><img src="img/lazer4.jpg" class="img-responsive"></a></div>
       </div>
</div><br><br><br><br><br>
<?php include_once("footer.php"); ?>