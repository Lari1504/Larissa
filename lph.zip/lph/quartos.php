<?php 
session_start(); // Inicia a sessão
?>

<?php include_once("header.php"); ?>
<br><br><br><br>
<h1>Quartos</h1><br><br>
<main>
    <section class="rooms-container">
        <div class="room">
            <img src="img/quartoesuite1.jpg" alt="Quarto de hotel">
            <h2>Quarto Casal/solteiro</h2>
            <p>Descrição do quarto. Quarto de casal/solteiro.</p>
            <p><strong>Preço:</strong> R$ 300 por noite</p>
            <button>Reservar</button>
        </div>
        <br><br>
        <div class="room">
            <img src="img/quartoesuite2.jpg" alt="Quarto de hotel">
            <h2>Suíte Família</h2>
            <p>Descrição do quarto. Quarto simples com 2 camas para família.</p>
            <p><strong>Preço:</strong> R$ 350 por noite</p>
            <button>Reservar</button> 
        </div> <br><br>
        <div class="room">
            <img src="img/quartoesuite3.jpg" alt="Quarto de hotel">
            <h2>Suíte Família</h2>
            <p>Descrição do quarto. Quarto simples com 2 camas e sala para família.</p>
            <p><strong>Preço:</strong> R$ 350 por noite</p>
            <button>Reservar</button>
        </div> <br><br>
        <div class="room">
            <img src="img/quartoesuite4.jpg" alt="Quarto de hotel">
            <h2>Suíte Presidencial</h2>
            <p>Descrição do quarto. Quarto presidencial com escritório e vista para a cidade.</p>
            <p><strong>Preço:</strong> R$ 500 por noite</p>
            <button>Reservar</button>
        </div> <br><br>
        <div class="room">
            <img src="img/quartoesuite5.jpg" alt="Quarto de hotel">
            <h2>Quarto Casal/solteiro</h2>
            <p>Descrição do quarto.Quarto de casal/solteiro.</p>
            <p><strong>Preço:</strong> R$ 300 por noite</p>
            <button>Reservar</button>
        </div> <br><br><br><br><br><br><br><br>
    </section>
</main>

<?php include_once("footer.php"); ?>
