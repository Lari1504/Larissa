<?php
include_once("conecao.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    // Inserir os dados na tabela
    $query = "INSERT INTO login (email, nome, senha, data_cadastro) VALUES (?, ?, ?, NOW())";
    $stmt = $conexao->prepare($query);
    $stmt->bind_param("sss", $email, $username, $password);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Dados inseridos com sucesso! <br>";
        echo "<a href='login.php'>Ir para a tela de login</a>";
    } else {
        echo "Erro ao inserir os dados. <br>";
        echo "<a href='registro.php'>Tentar novamente</a>";
    }

}
?>

