<?php
// Parâmetros de conexão com o banco de dados
define('HOST', 'localhost');
define('USUARIO', 'root');
define('SENHA', '1234');
define('DB', 'hotel');

// Estabelecer uma conexão com o banco de dados
$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB);

// Verificar a conexão
if (!$conexao) {
    die('Falha na conexão: ' . mysqli_connect_error());
}

// Definir o conjunto de caracteres
mysqli_set_charset($conexao, 'utf8');

//echo 'Conexão bem-sucedida com o banco de dados';
?>
