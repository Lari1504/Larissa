<footer>
    <p>&copy; <?php echo date("Y"); ?> Live Palace Hotel. Todos os direitos reservados a Larissa Tauanny.</p>
</footer>
<a href="#home" class="toTop scroll"><i class="fa fa-angle-up"></i></a>
</body>
</html>
