<?php include_once("header.php"); ?>

<div class="container">
    <h2>Carrinho de Compras</h2>
   
    <div class="carrinho" style="margin: 0 auto; text-align: center;">
        <h3>Itens no Carrinho</h3>
        <ul id="itens-carrinho" style="text-align: center;">
            <?php
            if(isset($_GET['item']) && isset($_GET['preco'])) {
                $item = $_GET['item'];
                $preco = $_GET['preco'];
                echo "<li>$item - R$ $preco</li>";
            } else {
                echo "<li>Nenhum item no carrinho.</li>";
            }
            ?>
        </ul>
        <p>Total: R$ <span id="total-carrinho">
            <?php
            if(isset($_GET['preco'])) {
                $preco = $_GET['preco'];
                echo $preco;
            } else {
                echo "0.00";
            }
            ?>
        </span></p>
        <p>Selecione a forma de pagamento:</p>
        <select id="metodo-pagamento">
            <option value="cartao">Cartão de Crédito e Débito</option>
            <option value="pix">PIX</option>
            <option value="boleto">Boleto</option>
        </select>
        <br><br>
        <div style="text-align: center;">
            <button onclick="pagar()">Pagar</button>
            <button onclick="location.href='consumo.php';">Cancelar</button>
        </div>
    </div>
</div>

<script>
    function pagar() {
        var metodoPagamento = document.getElementById("metodo-pagamento").value;
        var mensagem;

        switch (metodoPagamento) {
            case "cartao":
                mensagem = "Forma de pagamento: Cartão de crédito e débito - Pagamento realizado com sucesso!";
                break;
            case "pix":
                mensagem = "Forma de pagamento: PIX - Pagamento realizado com sucesso!";
                break;
            case "boleto":
                mensagem = "Forma de pagamento: Boleto - Boleto gerado! Por favor, aguarde o processamento.";
                break;
            default:
                mensagem = "Forma de pagamento inválida!";
                break;
        }

        alert(mensagem);
        limparCarrinho();
    }

    function limparCarrinho() {
        window.location.href = 'consumo.php';
    }
</script>

<?php include_once("footer.php"); ?>
