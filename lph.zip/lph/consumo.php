<?php include_once("header.php"); ?>

<div class="container" style="text-align: center;">
    <h2>Página de Consumo</h2>
    <p>Bem-vindo à galeria de consumo do Hotel.</p>
   
    <div class="consumo">
        <h3>Itens de Consumo</h3>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Preço</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $consumo = array(
                    "Café/Café com Leite" => 2.50,
                    "Bolinho" => 5.00,
                    "Água" => 4.50,
                    "Whisky (Royal Salute 21)" => 1090.00,
                    "Feijoada" => 25.00,
                    "Pizza (sabores ao seu critério/não é incluso bebida)" => 22.50,
                    "Prato Especial (Risoto de Camarão)" => 49.99
                );

                foreach ($consumo as $item => $preco) {
                    echo "<tr>";
                    echo "<td>$item</td>";
                    echo "<td>R$ $preco</td>";
                    echo "<td><a href='carrinho.php?item=$item&preco=$preco'>Adicionar ao Carrinho</a></td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once("footer.php"); ?>

<link rel="stylesheet" href="css/consumo.css">
