<?php
include_once("conecao.php");
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Consulta para verificar se o usuário e a senha estão corretos
    $query = "SELECT usuario_id, nome FROM login WHERE nome = ? AND senha = ?";
    $stmt = $conexao->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Autenticação bem-sucedida
        $stmt->bind_result($usuario_id, $nome);
        $stmt->fetch();

        // Iniciar a sessão (se ainda não estiver iniciada)
        session_start();
        $_SESSION['usuario_id'] = $usuario_id;
        $_SESSION['nome'] = $nome;

        // Redirecionar para a página de boas-vindas ou outra página após o login
        header("Location: index.php");
        exit;
    } else {
        // Exibir mensagem de erro e imagem de erro
        echo "<img src='erro.jpg' alt='Erro'>"; 
        echo "Usuário ou senha incorretos. <br>";
        echo "<a href='login.php'>Tentar novamente</a>";
    }

    $stmt->close();
}
?>
