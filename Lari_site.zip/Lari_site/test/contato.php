<?php include 'header.php';?>
<div class="container">

<h1 class="title">Contato</h1>

<!-- form -->
<div class="contact">
<div>
	<p>
	<br>
	Telefone de contato:+34 (93) 94272-5749 ou +34 (93) 3455-0899
	<br>
	Email:Livepalacehotel.23@gmail.com.br
	</p>
</div>


       <div class="row">
       	
       	<div class="col-sm-12">
       	<div class="map">
		   <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2992.942545836881!2d2.157671515289954!3d41.39705407926334!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a4a2950fa67fab%3A0xc26992a4fbab1043!2sGenerator%20Barcelona!5e0!3m2!1spt-PT!2sbr!4v1669994140285!5m2!1spt-PT!2sbr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
       	</div>

       </div>
</div>
</div>
<!-- form -->

</div>
<?php include 'footer.php';?>