<?php
session_start();
require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["email"]) && isset($_POST["senha"])) {
        $email = $conn->real_escape_string($_POST["email"]);
        $senha = $conn->real_escape_string($_POST["senha"]);

        $sql = "SELECT * FROM login WHERE email='$email' AND senha='$senha'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $usuario = $result->fetch_assoc();
            $_SESSION['nome_completo'] = $usuario['nome'];
            $_SESSION['email'] = $usuario['email'];
            header('Location: finalizar_compra.php');
            exit();
        } else {
            $error_message = "Usuário ou senha inválidos.";
        }
    } else {
        $error_message = "Por favor, insira seu e-mail e senha.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <header>
        <img src="IMG/logo.png" alt="Logo Live Palace Hotel">
    </header>
    
    <div class="container">
        <h2>Login</h2>
        <div class="login">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="login-form">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br>
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required><br>
                <input type="submit" value="Login">
            </form>
        </div>

        <p>Não tem uma conta? <a href="cadastro.php">Cadastre-se</a></p>

        <?php if (isset($error_message)) { ?>
            <p><?php echo $error_message; ?></p>
        <?php } ?>
    </div>

    <footer>
        <div>
            <p class="copyright" id="direitos_reservados">&copy; <?php echo date("Y"); ?> Live Palace Hotel. Todos os direitos reservados a Larissa Tauanny.</p>
        </div>
    </footer>
</body>
</html>
