<?php
session_start();
require 'db_connect.php'; // Inclua a configuração do banco de dados

// Carregar autoload do Composer
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $conn->real_escape_string($_POST['nome']);
    $email = $conn->real_escape_string($_POST['email']);
    $telefone = $conn->real_escape_string($_POST['telefone']);
    $endereco = $conn->real_escape_string($_POST['endereco']);
    $forma_pagamento = $conn->real_escape_string($_POST['forma_pagamento']);

    // Aqui você pode adicionar a lógica para salvar os dados no banco de dados, se necessário

    $mail = new PHPMailer(true);
try {
    // Configurações do servidor SMTP
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';  // Defina o servidor SMTP correto
    $mail->SMTPAuth = true;
    $mail->Username = 'seuemail@gmail.com';  // Seu usuário de SMTP
    $mail->Password = 'suasenha';  // Sua senha de SMTP
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Habilitar criptografia TLS, `ssl` também é aceito
    $mail->Port = 587;  // Porta TCP para TLS

    // Remetente
    $mail->setFrom('seuemail@gmail.com', 'Live Palace Hotel');

    // Destinatário
    $mail->addAddress($email, $nome);

    // Conteúdo do e-mail
    $mail->isHTML(true);
    $mail->Subject = 'Comprovante de Compra - Live Palace Hotel';
    $mail->Body    = "
    <html>
    <head>
    <title>Comprovante de Compra</title>
    </head>
    <body>
    <h2>Obrigado por sua compra, $nome!</h2>
    <p>Detalhes da sua compra:</p>
    <p><strong>Nome:</strong> $nome</p>
    <p><strong>E-mail:</strong> $email</p>
    <p><strong>Telefone:</strong> $telefone</p>
    <p><strong>Endereço:</strong> $endereco</p>
    <p><strong>Forma de Pagamento:</strong> $forma_pagamento</p>
    <br>
    <p>Atenciosamente,</p>
    <p>Equipe Live Palace Hotel</p>
    </body>
    </html>
    ";

    $mail->send();
    echo 'E-mail enviado com sucesso.';
} catch (Exception $e) {
    echo "Falha ao enviar o e-mail. Mailer Error: {$mail->ErrorInfo}";
}
    // Redirecionar para uma página de confirmação
    header('Location: confirmacao_compra.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processar Compra</title>
</head>
<body>
    <p>Processando sua compra...</p>
</body>
</html>
