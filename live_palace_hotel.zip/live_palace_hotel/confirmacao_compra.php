<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compra Confirmada</title>
</head>
<body>
    <header>
        <img src="IMG/logo.png" alt="Logo Live Palace Hotel">
    </header>

    <div class="container">
        <h2>Compra Confirmada</h2>
        <p>Obrigado por sua compra! Um comprovante foi enviado para o seu e-mail.</p>
        <button onclick="window.location.href='index.php'">Voltar ao Início</button>
    </div>

    <footer>
        <div>
            <p>&copy; <?php echo date("Y"); ?> Live Palace Hotel. Todos os direitos reservados a Larissa Tauanny.</p>
        </div>
    </footer>
</body>
</html>
